import React from 'react'
import Dashboard from './Dashboard'

const AddEvent = () => {
  return (
    <>
        <Dashboard/>
        
    </>
  )
}

export default AddEvent