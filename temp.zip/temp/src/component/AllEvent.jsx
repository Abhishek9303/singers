import React from "react";
import Navbr from "./Navbr";
import AllItems from "./AllItems";
import Footer from "./Footer";

const AllEvent = () => {
  return (
    <div>
      <Navbr />
      <AllItems />
      <Footer />
    </div>
  );
};

export default AllEvent;
