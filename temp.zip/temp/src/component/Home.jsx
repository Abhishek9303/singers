import React from "react";
import Allpage from "./Allpage";
import Navbr from "./Navbr";
import Footer from "./Footer";

export default function () {
  return (
    <div>
      <Navbr />
      <Allpage />
    </div>
  );
}
