import React from 'react'
import Navbr from './Navbr'
import Pagetwo from './Pagetwo'
import Footer from './Footer'

const ImageEvent = () => {
  return (
    <div>
        <Navbr/>
        <Pagetwo/>
        <Footer/>
    </div>
  )
}

export default ImageEvent